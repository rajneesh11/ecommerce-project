package com.ekart.eKartOrderService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
