package com.ekart.eKartShippingService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EKartShippingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EKartShippingServiceApplication.class, args);
	}

}
