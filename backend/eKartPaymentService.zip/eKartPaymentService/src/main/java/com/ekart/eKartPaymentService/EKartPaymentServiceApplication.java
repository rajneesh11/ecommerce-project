package com.ekart.eKartPaymentService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EKartPaymentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EKartPaymentServiceApplication.class, args);
	}

}
