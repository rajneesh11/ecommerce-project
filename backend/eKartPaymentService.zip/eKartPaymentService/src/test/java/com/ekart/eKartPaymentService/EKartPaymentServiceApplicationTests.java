package com.ekart.eKartPaymentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
