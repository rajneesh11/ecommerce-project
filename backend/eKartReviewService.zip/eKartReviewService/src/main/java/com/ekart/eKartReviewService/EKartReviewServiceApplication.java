package com.ekart.eKartReviewService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EKartReviewServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EKartReviewServiceApplication.class, args);
	}

}
