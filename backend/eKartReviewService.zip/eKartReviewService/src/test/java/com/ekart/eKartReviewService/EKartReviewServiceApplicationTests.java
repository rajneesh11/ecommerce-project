package com.ekart.eKartReviewService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartReviewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
